package com.company;

public enum MovementVector {
    RIGHT,
    LEFT,
    DOWN,
    UP,
}
