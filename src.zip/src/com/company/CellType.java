package com.company;

public enum CellType {
    FREE,
    TAIL,
    HEAD,
    APPLE,
    WALL
}
