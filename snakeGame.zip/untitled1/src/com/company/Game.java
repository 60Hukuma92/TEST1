package com.company;

public class Game {
    private boolean gameEnded;

    private final CellType[][] gameField;
    private MovementVector direction;

    private int headX;
    private int headY;

    public Game(Settings settings) {
        this.gameField = initField(settings.getFieldSize(), settings.getFieldSize());
        this.gameEnded = false;
        this.direction = settings.getDirection();
    }

    private CellType[][] initField(int fieldSize, int length) {
        headX = fieldSize / 2;
        headY = fieldSize / 2;

        CellType[][] field = new CellType[fieldSize][fieldSize];
        initSnake(field, length);
        for (int r = 0; r < field.length; r++) {
            if (r == 0 || r == fieldSize - 1 || c == 0 || fieldSize - 1)
        }
    }

    private void initSnake(CellType[][] field, int length) {
        field[headX][headY] = CellType.HEAD;
        for (int col = headX; ; col--) {

        }
    }
}
